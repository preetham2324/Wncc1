# CodeWars v1 : Virus Wars

Find the documentation of functions, Game Details and other instructions for India's first Bot-Programming Contest [here](https://www.notion.so/CodeWars-v1-Virus-Wars-89501f96c23d484cbdea9c76227a61d5).

Have a great Introduction to Programming!

![image description](logo.jpeg)

